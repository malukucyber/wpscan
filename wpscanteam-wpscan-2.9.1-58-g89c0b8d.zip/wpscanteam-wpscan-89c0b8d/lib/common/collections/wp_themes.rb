# encoding: UTF-8

require 'common/collections/wp_themes/detectable'

class WpThemes < WpItems
  extend WpThemes::Detectable

end
